/**
 * @file:   k_memory.c
 * @brief:  kernel memory managment routines
 * @author: Yiqing Huang
 * @date:   2014/01/17
 */

#include "k_memory.h"
#include "k_process.h"

#ifdef DEBUG_0
#include "printf.h"
#endif /* ! DEBUG_0 */

#define PROC_STACK_SIZE 1024
#define HEAP_BLOCK_HEADER_SIZE sizeof(mem_block_header)
#define HEAP_BLOCK_SIZE 128
#define PCB_SIZE sizeof(PCB)

#define NUM_BITS_PER_BYTE 8
#define NUM_BITS_PER_WORD (sizeof(U32) * NUM_BITS_PER_BYTE)
#define MEM_MAP_WORD_COUNT 8

// for pointer arithmetic
#define HEAP_CHUNK_WORD_SIZE (HEAP_BLOCK_SIZE/sizeof(U32))

/* ----- Global Variables ----- */
U32 *gp_stack; /* The last allocated stack low address. 8 bytes aligned */
               /* The first stack starts at the RAM high address */
	       /* stack grows down. Fully decremental stack */
				 
U32 *heap_start; /* The start of the heap */

U32 mem_avail[MEM_MAP_WORD_COUNT] = {0}; // bits to tell mem availibility , 0 available, 1 not available

U32 allocCounter = 0;

/**
 * @brief: Initialize RAM as follows:

0x10008000+---------------------------+ High Address
          |    Proc 1 STACK           |
          |---------------------------|
          |    Proc 2 STACK           |
          |---------------------------|<--- gp_stack
          |                           |
          |        HEAP               |
          |                           |
          |---------------------------|<--- heap_start
          |        PCB 2              |
          |---------------------------|
          |        PCB 1              |
          |---------------------------|
          |        PCB pointers       |
          |---------------------------|<--- gp_pcbs
          |        Padding            |
          |---------------------------|  
          |Image$$RW_IRAM1$$ZI$$Limit |
          |...........................|          
          |       RTX  Image          |
          |                           |
0x10000000+---------------------------+ Low Address

*/

/**
 * @brief: Set a memory block to "allocated" in the memory map
 * @param: allocatedBlockNumber,	The block number of the memory block to be allocated
 */
int mark_memory_used(U8 allocatedBlockNumber)
{
	U32 bitsPerWord = NUM_BITS_PER_WORD;
	U8 wordIndex = allocatedBlockNumber / bitsPerWord;
	U8 bitInWord;
	if (wordIndex >= MEM_MAP_WORD_COUNT)
	{
			return RTX_ERR;
	}
	
	bitInWord = allocatedBlockNumber-(NUM_BITS_PER_WORD * wordIndex);
	
	if(mem_avail[wordIndex] & (0x1 << bitInWord)){
		return RTX_ERR;
	}
	
	mem_avail[wordIndex] = mem_avail[wordIndex] | (0x1 << bitInWord);
	
	return RTX_ERR;
}

/**
 * @brief: Set a memory block to "free" in the memory map
 * @param: freedBlockNumber,	The block number of the memory block to be freed
 */
int mark_memory_freed(U8 freedBlockNumber)
{
	U8 wordIndex = freedBlockNumber/NUM_BITS_PER_WORD;
	U8 bitInWord;
	if (wordIndex >= MEM_MAP_WORD_COUNT)
	{
			return RTX_ERR;
	}
	
	bitInWord = freedBlockNumber-(NUM_BITS_PER_WORD * wordIndex);
	if(!(mem_avail[wordIndex] & (0x1 << bitInWord))){
		return RTX_ERR;
	}
	
	//else
	mem_avail[wordIndex] = mem_avail[wordIndex] & ~(0x1 << bitInWord);
	return RTX_OK;
}

void resize_heap(){
	int numberOfMemoryBlocks = (gp_stack - heap_start)/HEAP_CHUNK_WORD_SIZE;
	int i;
	
	for(i = numberOfMemoryBlocks; i < NUM_BITS_PER_WORD * MEM_MAP_WORD_COUNT; i++){
		mark_memory_used((U8) i);
	}
}

void memory_init(void)
{
	U32 *p_end = (U32 *)&Image$$RW_IRAM1$$ZI$$Limit;
	int i;
	
	/* 4 bytes padding */
	p_end += 1;
	
	/* allocate memory for pcb pointers   */
	gp_pcbs = (PCB **)p_end;
	p_end += (NUM_TOTAL_PROCS)* sizeof(PCB *);
  
	for ( i = 0; i < NUM_TOTAL_PROCS; i++ ) {
		gp_pcbs[i] = (PCB *)p_end;
		p_end += sizeof(PCB); 
	}
#ifdef DEBUG_0  
	//printf("gp_pcbs[0] = 0x%x \n", gp_pcbs[0]);
	//printf("gp_pcbs[1] = 0x%x \n", gp_pcbs[1]);
#endif
	
	/* prepare for alloc_stack() to allocate memory for stacks */
	
	gp_stack = (U32 *)RAM_END_ADDR;
	if ((U32)gp_stack & 0x04) { /* 8 bytes alignment */
		--gp_stack; 
	}
	
  
	/* allocate memory for heap and stack*/
	heap_start = p_end;
	
	resize_heap();
}

/**
 * @brief: allocate stack for a process, align to 8 bytes boundary
 * @param: size, stack size in bytes
 * @return: The top of the stack (i.e. high address)
 * POST:  gp_stack is updated.
 */

U32 *alloc_stack(U32 size_b) 
{
	U32 *sp;
//	int i;
	sp = gp_stack; /* gp_stack is always 8 bytes aligned */
	
	/* update gp_stack */
	gp_stack = (U32 *)((U8 *)sp - size_b);
	
	/* 8 bytes alignement adjustment to exception stack frame */
	if ((U32)gp_stack & 0x04) {
		--gp_stack; 
	}
	
	resize_heap();
	/*
	for (i = 0; i < MEM_MAP_WORD_COUNT; i++)
	{
		printf("Mem map word %d: 0x%x\n", i, mem_avail[i]);
	}*/
	
	return sp;
}

void *k_request_memory_block(void) {
	
	int i, j;
	U32 current;
	U32* ptr;
	
	atomic(ON);
	while(1){
		for (i = 0; i<MEM_MAP_WORD_COUNT; i++){
			current = mem_avail[i];
			for (j = 0 ; j<NUM_BITS_PER_WORD ; j++) {
			
				if (!(current&0x1)){
					mem_avail[i] |= 0x1 << j; // Sets the bit to 1
					ptr = heap_start + HEAP_CHUNK_WORD_SIZE*(NUM_BITS_PER_WORD*i+j);

					atomic(OFF);
	allocCounter++;
					return (void*) ptr;
				}				
				current = current>>1;	
			}
		}
		k_wait_for_memory();
	}
	//this return shall never be reached
#ifdef DEBUG_0
	printf("ERROR in k_request_memory_block: reached unreacheable return statement\n");
#endif

	atomic(OFF);

	return NULL;
}

void *k_request_memory_block_no_block(void) {
	
	int i, j;
	U32 current;
	U32* ptr;
	
	atomic(ON);

		for (i = 0; i<MEM_MAP_WORD_COUNT; i++){
			current = mem_avail[i];
			for (j = 0 ; j<NUM_BITS_PER_WORD ; j++) {
			
				if (!(current&0x1)){
					mem_avail[i] |= 0x1 << j; // Sets the bit to 1
					ptr = heap_start + HEAP_CHUNK_WORD_SIZE*(NUM_BITS_PER_WORD*i+j);

					atomic(OFF);
allocCounter++;
					return (void*) ptr;
				}				
				current = current>>1;	
			}
		}
	atomic(OFF);

	return NULL;
}

int k_release_memory_block(void *p_mem_blk) {

	//calculuate position
	
	U32 block_index;
	
	if(p_mem_blk < heap_start || p_mem_blk>=gp_stack){
		return RTX_ERR;
	}

	atomic(ON);
	
	block_index = ((U32*)p_mem_blk - heap_start)/HEAP_CHUNK_WORD_SIZE;
	if(RTX_ERR == mark_memory_freed((U8)block_index)){
		atomic(OFF);
		return RTX_ERR;
	}
	
	k_memory_available();
		
allocCounter--;
	atomic(OFF);
	return RTX_OK;
}

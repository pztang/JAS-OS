/**
 * @file:   k_process.c  
 * @brief:  process management C file
 * @author: Yiqing Huang
 * @author: Thomas Reidemeister
 * @date:   2014/01/17
 * NOTE: The example code shows one way of implementing context switching.
 *       The code only has minimal sanity check. There is no stack overflow check.
 *       The implementation assumes only two simple user processes and NO HARDWARE INTERRUPTS. 
 *       The purpose is to show how context switch could be done under stated assumptions. 
 *       These assumptions are not true in the required RTX Project!!!
 *       If you decide to use this piece of code, you need to understand the assumptions and
 *       the limitations. 
 */

#include <LPC17xx.h>
#include <system_LPC17xx.h>
#include "uart_polling.h"
#include "k_process.h"

#ifdef DEBUG_0
#include "printf.h"
#endif /* DEBUG_0 */

#define NULL_PROCESS_ID					0
#define NULL_PROCESS_STACK_SIZE	64
#define NULL_PROCESS						gp_pcbs[0]

/* ----- Global Variables ----- */
PCB **gp_pcbs;                  /* array of pcbs */
PCB *gp_current_process = NULL; /* always point to the current RUN process */
Queue priority_ready_queue[PRIORITY_COUNT];
Queue memory_blocked_queue;

/* process initialization table */
PROC_INIT g_proc_table[NUM_TEST_PROCS+1];
extern PROC_INIT g_test_procs[NUM_TEST_PROCS];

// null process declaration
void null_process(void);

int queue_init(Queue* q){
	q->end = 0;
	return 0;
}

// return 1 if empty, 0 if not empty
int queue_is_empty(Queue* q){
	if(0 == q->end){
		return 1;
	}
	
	return 0;
}

PCB* queue_peek(Queue* q){
	if(queue_is_empty(q)){
		return NULL;
	}
	
	return q->queueElements[0];
};

PCB* queue_pop(Queue* q){
	PCB* popped = NULL;
	int i;
	if(queue_is_empty(q)){
		return NULL;
	}
	
	popped = q->queueElements[0];
	
	q->end--;
	for (i = 0; i < q->end; i++){
		q->queueElements[i] = q->queueElements[i+1];
	}
	
	return popped;
};

int queue_push(Queue* q, PCB* process)
{
	if(NUM_TEST_PROCS-1 < q->end){
		return RTX_ERR;
	}
	
	q->queueElements[q->end] = process;
	
	q->end++;
	
	return 0;
};

int queue_remove_process(Queue* q, PCB* process){
	int i;
	for (i = 0; i < q->end; i++){
		if (q->queueElements[i] == process){
			q->queueElements[i] = NULL;
			
			for(; i < q->end; i++){
				q->queueElements[i] = q->queueElements[i-1];
			}
			q->end--;
			
			return 0;
		}
	}
	return RTX_ERR;
}


/**
 * @biref: initialize all processes in the system
 * NOTE: We assume there are only two user processes in the system in this example.
 */
void process_init() 
{
	int i;
	U32 *sp;
  
	// Initialize ready queue
	for(i = 0; i<PRIORITY_COUNT; i++){
		queue_init(&priority_ready_queue[i]);
	}
	
	// Initialize blocked queue
	queue_init(&memory_blocked_queue);
	
        /* fill out the initialization table */
	set_test_procs();
	
	// Initialize null process
	g_proc_table[0].m_pid = NULL_PROCESS_ID;
	g_proc_table[0].m_stack_size = NULL_PROCESS_STACK_SIZE;
	g_proc_table[0].m_priority = PRIORITY_NULL;
	g_proc_table[0].mpf_start_pc = &null_process;
	
	for ( i = NULL_PROCESS_ID+1; i < NUM_TEST_PROCS + 1; i++ ) {
		g_proc_table[i].m_pid = g_test_procs[i-1].m_pid;
		g_proc_table[i].m_priority = g_test_procs[i-1].m_priority;
		g_proc_table[i].m_stack_size = g_test_procs[i-1].m_stack_size;
		g_proc_table[i].mpf_start_pc = g_test_procs[i-1].mpf_start_pc;
	}
  
	/* initilize exception stack frame (i.e. initial context) for each process */
	for ( i = 0; i < NUM_TEST_PROCS + 1; i++ ) {
		int j;
		(gp_pcbs[i])->m_pid = (g_proc_table[i]).m_pid;
		(gp_pcbs[i])->m_priority = (g_proc_table[i]).m_priority;
		(gp_pcbs[i])->m_state = NEW;
		
		sp = alloc_stack((g_proc_table[i]).m_stack_size);
		*(--sp)  = INITIAL_xPSR;      // user process initial xPSR  
		*(--sp)  = (U32)((g_proc_table[i]).mpf_start_pc); // PC contains the entry point of the process
		for ( j = 0; j < 6; j++ ) { // R0-R3, R12 are cleared with 0
			*(--sp) = 0x0;
		}
		(gp_pcbs[i])->mp_sp = sp;
	}
	
	// add processes to queue
	for(i = NULL_PROCESS_ID+1; i < NUM_TEST_PROCS+1; i++){
		queue_push(&priority_ready_queue[gp_pcbs[i]->m_priority], gp_pcbs[i]);
	}
}

/*@brief: scheduler, pick the pid of the next to run process
 *@return: PCB pointer of the next to run process
 *         NULL if error happens
 *POST: if gp_current_process was NULL, then it gets set to pcbs[0].
 *      No other effect on other global variables.
 * NOTE: POPS next process from ready queue (no state change or push)
 *
 */

PCB *scheduler(void)
{
	int i;
	PCB* next_process;
	for(i = 0; i < PRIORITY_COUNT; i++){
		if(!queue_is_empty(&priority_ready_queue[i])){
			next_process = queue_peek(&priority_ready_queue[i]);
			if(NULL == gp_current_process || BLOCKED == gp_current_process->m_state || next_process->m_priority <= gp_current_process->m_priority){
				return queue_pop(&priority_ready_queue[i]);
			}else{
				return gp_current_process;
			}
		}
	}
	
	if(NULL == gp_current_process){
		return NULL_PROCESS;
	}
	
	return gp_current_process;
}

/*@brief: switch out old pcb (p_pcb_old), run the new pcb (gp_current_process)
 *@param: p_pcb_old, the old pcb that was in RUN
 *@return: RTX_OK upon success
 *         RTX_ERR upon failure
 *PRE:  p_pcb_old and gp_current_process are pointing to valid PCBs.
 *POST: if gp_current_process was NULL, then it gets set to pcbs[0].
 *      No other effect on other global variables.
 *
 * NOTE: STATE TRANSITIONS for RDY and RUN ONLY (no push/pop or BLOCKED transitions)
 */
int process_switch(PCB *p_pcb_old) 
{
	PROC_STATE_E state;
	
	state = gp_current_process->m_state;

	if (state == NEW) {
		if (gp_current_process != p_pcb_old && p_pcb_old->m_state != NEW) {
			if(BLOCKED != p_pcb_old->m_state){
				p_pcb_old->m_state = RDY; 
			}
			p_pcb_old->mp_sp = (U32 *) __get_MSP();
		}
		gp_current_process->m_state = RUN;
		__set_MSP((U32) gp_current_process->mp_sp);
		__rte();  // pop exception stack frame from the stack for a new processes
	} 
	
	/* The following will only execute if the if block above is FALSE */

	if (gp_current_process != p_pcb_old) {
		if (state == RDY){ 		
			
			if(BLOCKED != p_pcb_old->m_state){
				p_pcb_old->m_state = RDY; 
			}
			
			p_pcb_old->mp_sp = (U32 *) __get_MSP(); // save the old process's sp
			gp_current_process->m_state = RUN;
			
			__set_MSP((U32) gp_current_process->mp_sp); //switch to the new proc's stack  
			
		} else {
			gp_current_process = p_pcb_old; // revert back to the old proc on error
			return RTX_ERR;
		} 
	}
	return RTX_OK;
}
/**
 * @brief release_processor(). 
 * @return RTX_ERR on error and zero on success
 * POST: gp_current_process gets updated to next to run process
 * NOTE: PUSH to READY QUEUE only (no push BLOCKED queue or transitions)
 */
int k_release_processor(void)
{
	PCB *p_pcb_old = NULL;
	
	p_pcb_old = gp_current_process;
	gp_current_process = scheduler();
	
	if (gp_current_process == p_pcb_old  ) {
		// revert back to the old process
		return RTX_OK;
	}
	
	if ( p_pcb_old == NULL ) {
		p_pcb_old = NULL_PROCESS;
	}else{
		if(BLOCKED != p_pcb_old->m_state){
			queue_push(&priority_ready_queue[p_pcb_old->m_priority], p_pcb_old);
		}
	}
	
	process_switch(p_pcb_old);
	return RTX_OK;
}


/**
 * @brief Change the priority of a process
 * @return RTX_ERR on error and zero on success
 * @param process_id, 	id of the process
 * @param priority,			the priority to change to
 * POST: priority of given process is changed
 */
int k_set_process_priority(int process_id, int priority)
{
	int orig_process_priority; 
	// Check process_id and priority are valid
	if (process_id < 0 || process_id > NUM_TEST_PROCS
		|| priority < HIGH || priority > PRIORITY_NULL)
	{
		return RTX_ERR;
	}
	
	// Null process can only have PRIORITY_NULL
	if(process_id == 0 && priority != PRIORITY_NULL){
		return RTX_ERR;
	}
	
	// Only null process can have PRIORITY_NULL
	if(process_id != 0 && priority == PRIORITY_NULL){
		return RTX_ERR;
	}
	
	orig_process_priority = gp_pcbs[process_id]->m_priority;
	
	// If desired priority is different from process priority
	if(priority != gp_pcbs[process_id]->m_priority){
		
		// Changed process is not current process
		if(gp_current_process != gp_pcbs[process_id]){
			gp_pcbs[process_id]->m_priority = priority;
			
			// if not in ready queue then just return
			if(queue_remove_process(&priority_ready_queue[orig_process_priority] , gp_pcbs[process_id])){
				return 0;
			}
			
			if(queue_push(&priority_ready_queue[priority], gp_pcbs[process_id])){
				return RTX_ERR;
			}
			
			// Preemption
			if(gp_pcbs[process_id]->m_priority < gp_current_process->m_priority){
				return k_release_processor();
			}
			return 0;
		}else{
			//Current Process is changed process
			gp_current_process->m_priority = priority;
			
			// Preemption
			return k_release_processor();
		}
	}
	
	// Else
	return 0;
	
}


/**
 * @brief Get the priority of a process
 * @return priority of the process if process exists, INVALID_PRIORITY(-1) otherwise
 * @param process_id, 	id of the process
 * POST: priority of given process is changed
 */
int k_get_process_priority(int process_id)
{
	// Check process_id validity
	if (process_id < 0 || process_id > NUM_TEST_PROCS)
	{
		return INVALID_PRIORITY;
	}
	
	return gp_pcbs[process_id]->m_priority;
	
}

// k_alloc_memory calls this if there is no more memory
// this function both PUSHES to QUEUE and SETS STATE
int k_wait_for_memory(void){
	queue_push(&memory_blocked_queue, gp_current_process);
	gp_current_process->m_state = BLOCKED;
	k_release_processor();
	
	return 0;
}

// k_free_memory calls this
// this function both POPS from QUEUE and SETS STATE
int k_memory_available (void){
	PCB* blocked_process;
	
	if(queue_is_empty(&memory_blocked_queue)){
		return 0;
	}
	
	//else
	blocked_process = queue_pop(&memory_blocked_queue);
	blocked_process->m_state = RDY;
	queue_push(&priority_ready_queue[blocked_process->m_priority], blocked_process);
	// Preemption
	if(blocked_process->m_priority > gp_current_process->m_priority){
		k_release_processor();
	}
	return 0;
}


void null_process (void){
	while(1){
		k_release_processor();
	}
}
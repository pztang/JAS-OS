/**
 * @file:   k_process.c  
 * @brief:  process management C file
 * @author: Yiqing Huang
 * @author: Thomas Reidemeister
 * @date:   2014/01/17
 * NOTE: The example code shows one way of implementing context switching.
 *       The code only has minimal sanity check. There is no stack overflow check.
 *       The implementation assumes only two simple user processes and NO HARDWARE INTERRUPTS. 
 *       The purpose is to show how context switch could be done under stated assumptions. 
 *       These assumptions are not true in the required RTX Project!!!
 *       If you decide to use this piece of code, you need to understand the assumptions and
 *       the limitations. 
 */

#include <LPC17xx.h>
#include <system_LPC17xx.h>

#include "uart_polling.h"
#ifdef _DEBUG_HOTKEYS
#include "util.h"
#endif

#include "k_process.h"
#include "k_memory.h"
#include "timer.h"
#include "uart.h"


#ifdef DEBUG_0
#include "printf.h"
#endif /* DEBUG_0 */

#define NULL_PROCESS_ID					0
#define NULL_PROCESS_STACK_SIZE	128
#define NULL_PROCESS						gp_pcbs[0]

#define I_PROCESS_STACK_SIZE		128

#define USER_PROCESS_START			(NULL_PROCESS_ID + 1)
#define STRESS_PROCESS_START		(USER_PROCESS_START + NUM_TEST_PROCS)
#define USER_PROCESS_END				(I_PROCESS_TIMER_ID)


/* ----- Global Variables ----- */
PCB **gp_pcbs;                  /* array of pcbs */
PCB *gp_current_process = NULL; /* always point to the current RUN process */
PCB *gp_interrupted_process = NULL; /* points to the interrupted process */
Queue priority_ready_queue[PRIORITY_COUNT];
Queue memory_blocked_queue;

/* process initialization table */
PROC_INIT g_proc_table[NUM_TOTAL_PROCS];
extern PROC_INIT g_test_procs[NUM_TEST_PROCS];
extern PROC_INIT g_stress_procs[NUM_STRESS_PROCS];
extern PROC_INIT g_set_priority;
extern PROC_INIT g_wall_clock;
extern PROC_INIT g_kcd;
extern PROC_INIT g_crt;

// null process declaration
void null_process(void);

// i process declaration
void timer_i_process(void);
void uart_i_process(void);

// super sketchy code
void new_process_shim(void);

extern volatile uint32_t g_timer_count;
extern uint8_t g_char_in;

int queue_init(Queue* q){
	q->end = 0;
	return 0;
}

// return 1 if empty, 0 if not empty
int queue_is_empty(Queue* q){
	if(0 == q->end){
		return 1;
	}
	
	return 0;
}

PCB* queue_peek(Queue* q){
	if(queue_is_empty(q)){
		return NULL;
	}
	
	return q->queueElements[0];
};

PCB* queue_pop(Queue* q){
	PCB* popped = NULL;
	int i;
	if(queue_is_empty(q)){
		return NULL;
	}
	
	popped = q->queueElements[0];
	
	q->end--;
	for (i = 0; i < q->end; i++){
		q->queueElements[i] = q->queueElements[i+1];
	}
	
	return popped;
};

int queue_push(Queue* q, PCB* process)
{
	if(NUM_TOTAL_PROCS-1 < q->end){
		return RTX_ERR;
	}
	
	q->queueElements[q->end] = process;
	
	q->end++;
	
	return 0;
};

int queue_remove_process(Queue* q, PCB* process){
	int i;
	for (i = 0; i < q->end; i++){
		if (q->queueElements[i] == process){
			q->queueElements[i] = NULL;
			
			for(; i < q->end; i++){
				q->queueElements[i] = q->queueElements[i-1];
			}
			q->end--;
			
			return 0;
		}
	}
	return RTX_ERR;
}

/**
 * Turns on/off IRQ
 */
int atomic(int status){
	int atomic_level;
	
	if(NULL == gp_current_process){
		if(status == ON){
			__disable_irq();
		}else if(status == OFF){
			__enable_irq();
		}else{
			return RTX_ERR;
		}
		return 0;
	}
	
	atomic_level = gp_current_process->atomic_level;
	
	if (status == ON)
	{
		gp_current_process->atomic_level++;
		__disable_irq();
	}
	else if (status == OFF)
	{
		if (atomic_level >= 2)
		{
			gp_current_process->atomic_level--;
		}
		else
		{
			gp_current_process->atomic_level = 0;
			__enable_irq();
		}
	}
	else
	{
		return RTX_ERR;
	}
	
	return 0;
}

/**
 * @biref: returns the pointer to PCB of the pid specified
 * NOTE: returns NULL if no match found
 */
PCB* get_process_from_id(U32 process_id)
{
	int i = 0;
	for (i = 1; i < NUM_TOTAL_PROCS; i++)
	{
		if (gp_pcbs[i]->m_pid == process_id)
		{
			return gp_pcbs[i];
		}
	}
	return NULL;
}


/**
 * @biref: initialize all processes in the system
 * NOTE: We assume there are only two user processes in the system in this example.
 */
void process_init() 
{
	int i;
	U32 *sp;
  
	// Initialize ready queue
	for(i = 0; i<PRIORITY_COUNT; i++){
		queue_init(&priority_ready_queue[i]);
	}
	
	// Initialize blocked queue
	queue_init(&memory_blocked_queue);
	
        /* fill out the initialization table */
	set_test_procs();
	set_special_usr_procs();
	
	// Initialize null process
	g_proc_table[0].m_pid = NULL_PROCESS_ID;
	g_proc_table[0].m_stack_size = NULL_PROCESS_STACK_SIZE;
	g_proc_table[0].m_priority = PRIORITY_NULL;
	g_proc_table[0].mpf_start_pc = &null_process;
	
	// Initialize test processes
	for ( i = USER_PROCESS_START; i < NUM_TEST_PROCS + USER_PROCESS_START; i++ ) {
		g_proc_table[i].m_pid = g_test_procs[i-USER_PROCESS_START].m_pid;
		g_proc_table[i].m_priority = g_test_procs[i-USER_PROCESS_START].m_priority;
		g_proc_table[i].m_stack_size = g_test_procs[i-USER_PROCESS_START].m_stack_size;
		g_proc_table[i].mpf_start_pc = g_test_procs[i-USER_PROCESS_START].mpf_start_pc;
	}
	
	// Initialize stress processes
	for ( i = STRESS_PROCESS_START; i < STRESS_PROCESS_START + NUM_STRESS_PROCS; i++ ) {
		g_proc_table[i].m_pid = g_stress_procs[i-STRESS_PROCESS_START].m_pid;
		g_proc_table[i].m_priority = g_stress_procs[i-STRESS_PROCESS_START].m_priority;
		g_proc_table[i].m_stack_size = g_stress_procs[i-STRESS_PROCESS_START].m_stack_size;
		g_proc_table[i].mpf_start_pc = g_stress_procs[i-STRESS_PROCESS_START].mpf_start_pc;
	}
	
	// Initialize additional user processes
	g_proc_table[SET_PRIORITY_PROC_ID].m_pid = g_set_priority.m_pid;
	g_proc_table[SET_PRIORITY_PROC_ID].m_priority = g_set_priority.m_priority;
	g_proc_table[SET_PRIORITY_PROC_ID].m_stack_size = g_set_priority.m_stack_size;
	g_proc_table[SET_PRIORITY_PROC_ID].mpf_start_pc = g_set_priority.mpf_start_pc;
	
	g_proc_table[WALL_CLOCK_PROC_ID].m_pid = g_wall_clock.m_pid;
	g_proc_table[WALL_CLOCK_PROC_ID].m_priority = g_wall_clock.m_priority;
	g_proc_table[WALL_CLOCK_PROC_ID].m_stack_size = g_wall_clock.m_stack_size;
	g_proc_table[WALL_CLOCK_PROC_ID].mpf_start_pc = g_wall_clock.mpf_start_pc;
	
	g_proc_table[KCD_PROC_ID].m_pid = g_kcd.m_pid;
	g_proc_table[KCD_PROC_ID].m_priority = g_kcd.m_priority;
	g_proc_table[KCD_PROC_ID].m_stack_size = g_kcd.m_stack_size;
	g_proc_table[KCD_PROC_ID].mpf_start_pc = g_kcd.mpf_start_pc;
	
	g_proc_table[CRT_PROC_ID].m_pid = g_crt.m_pid;
	g_proc_table[CRT_PROC_ID].m_priority = g_crt.m_priority;
	g_proc_table[CRT_PROC_ID].m_stack_size = g_crt.m_stack_size;
	g_proc_table[CRT_PROC_ID].mpf_start_pc = g_crt.mpf_start_pc;
	
	g_proc_table[I_PROCESS_TIMER_ID].m_pid = I_PROCESS_TIMER_ID;
	g_proc_table[I_PROCESS_TIMER_ID].m_priority = PRIORITY_NULL;
	g_proc_table[I_PROCESS_TIMER_ID].m_stack_size = I_PROCESS_STACK_SIZE;
	g_proc_table[I_PROCESS_TIMER_ID].mpf_start_pc = &timer_i_process;
	
	g_proc_table[I_PROCESS_UART_ID].m_pid = I_PROCESS_UART_ID;
	g_proc_table[I_PROCESS_UART_ID].m_priority = PRIORITY_NULL;
	g_proc_table[I_PROCESS_UART_ID].m_stack_size = I_PROCESS_STACK_SIZE;
	g_proc_table[I_PROCESS_UART_ID].mpf_start_pc = &uart_i_process;
	
	
	/* initilize exception stack frame (i.e. initial context) for each process */
	for ( i = 0; i < NUM_TOTAL_PROCS; i++ ) {
		int j;
		(gp_pcbs[i])->m_pid = (g_proc_table[i]).m_pid;
		(gp_pcbs[i])->m_priority = (g_proc_table[i]).m_priority;
		if(I_PROCESS_TIMER_ID == i || I_PROCESS_UART_ID == i){
			(gp_pcbs[i])->m_state = INTERRUPT;
		}else{
			(gp_pcbs[i])->m_state = NEW;
		}
		(gp_pcbs[i])->atomic_level = 0;
		(gp_pcbs[i])->first = NULL;
		(gp_pcbs[i])->last = NULL;
		
		sp = alloc_stack((g_proc_table[i]).m_stack_size);
		*(--sp)  = INITIAL_xPSR;      // user process initial xPSR  
		if(I_PROCESS_TIMER_ID == i || I_PROCESS_UART_ID == i){
			*(--sp)  = (U32)((g_proc_table[i]).mpf_start_pc); // PC contains the entry point of the process
		}else{
			*(--sp)  = (U32)(&new_process_shim); // PC contains the entry point of the process
		}
		for ( j = 0; j < 6; j++ ) { // R0-R3, R12 are cleared with 0
			*(--sp) = 0x0;
		}
		(gp_pcbs[i])->mp_sp = sp;
	}
	
	//queue_push(&priority_ready_queue[gp_pcbs[I_PROCESS_TIMER_ID]->m_priority], gp_pcbs[I_PROCESS_TIMER_ID]);
	//queue_push(&priority_ready_queue[gp_pcbs[I_PROCESS_UART_ID]->m_priority], gp_pcbs[I_PROCESS_UART_ID]);
	
	// add processes to queue
	for(i = USER_PROCESS_START; i < USER_PROCESS_END; i++){
		// do not add i processes to ready queue
		queue_push(&priority_ready_queue[gp_pcbs[i]->m_priority], gp_pcbs[i]);
	}
}

/*@brief: scheduler, pick the pid of the next to run process
 *@return: PCB pointer of the next to run process
 *         NULL if error happens
 *POST: if gp_current_process was NULL, then it gets set to pcbs[0].
 *      No other effect on other global variables.
 * NOTE: POPS next process from ready queue (no state change or push)
 *
 */

PCB *scheduler(void)
{
	int i;
	PCB* next_process;
	for(i = 0; i < PRIORITY_COUNT; i++){
		if(!queue_is_empty(&priority_ready_queue[i])){
			next_process = queue_peek(&priority_ready_queue[i]);
			if(NULL == gp_current_process ||
				MEM_BLOCKED == gp_current_process->m_state ||
				MSG_BLOCKED == gp_current_process->m_state ||
				next_process->m_priority <= gp_current_process->m_priority){
					
				return queue_pop(&priority_ready_queue[i]);
			}else{
				return gp_current_process;
			}
		}
	}
	
	if(NULL == gp_current_process ||
		gp_current_process->m_state == MEM_BLOCKED ||
		gp_current_process->m_state == MSG_BLOCKED){
		return NULL_PROCESS;
	}
	
	return gp_current_process;
}

/*@brief: switch out old pcb (p_pcb_old), run the new pcb (gp_current_process)
 *@param: p_pcb_old, the old pcb that was in RUN
 *@return: RTX_OK upon success
 *         RTX_ERR upon failure
 *PRE:  p_pcb_old and gp_current_process are pointing to valid PCBs.
 *POST: if gp_current_process was NULL, then it gets set to pcbs[0].
 *      No other effect on other global variables.
 *
 * NOTE: STATE TRANSITIONS for RDY and RUN ONLY (no push/pop or BLOCKED transitions)
 */
int process_switch(PCB *p_pcb_old) 
{
	PROC_STATE_E state;
	
	state = gp_current_process->m_state;

	if (state == NEW) {
		if (gp_current_process != p_pcb_old && p_pcb_old->m_state != NEW) {
			if(MEM_BLOCKED != p_pcb_old->m_state &&
				MSG_BLOCKED != p_pcb_old->m_state){
				p_pcb_old->m_state = RDY; 
			}
			p_pcb_old->mp_sp = (U32 *) __get_MSP();
		}
		gp_current_process->m_state = RUN;
		__set_MSP((U32) gp_current_process->mp_sp);
		__rte();  // pop exception stack frame from the stack for a new processes
	} 
	
	/* The following will only execute if the if block above is FALSE */

	if (gp_current_process != p_pcb_old) {
		if (state == RDY){ 		
			
			if(MEM_BLOCKED != p_pcb_old->m_state &&
				MSG_BLOCKED != p_pcb_old->m_state){
				p_pcb_old->m_state = RDY; 
			}
			
			p_pcb_old->mp_sp = (U32 *) __get_MSP(); // save the old process's sp
			gp_current_process->m_state = RUN;
			
			__set_MSP((U32) gp_current_process->mp_sp); //switch to the new proc's stack  
			
		} else {
			gp_current_process = p_pcb_old; // revert back to the old proc on error
			return RTX_ERR;
		} 
	}
	return RTX_OK;
}
/**
 * @brief release_processor(). 
 * @return RTX_ERR on error and zero on success
 * POST: gp_current_process gets updated to next to run process
 * NOTE: PUSH to READY QUEUE only (no push BLOCKED queue or transitions)
 */
int k_release_processor(void)
{
	PCB *p_pcb_old = NULL;

	atomic(ON);
	
	p_pcb_old = gp_current_process;
	gp_current_process = scheduler();
	
	if (gp_current_process == p_pcb_old  ) {
		// revert back to the old process
		atomic(OFF);
		return RTX_OK;
	}
	
	if ( p_pcb_old == NULL ) {
		p_pcb_old = NULL_PROCESS;
	}else{
		if(MEM_BLOCKED	 != p_pcb_old->m_state
			&& MSG_BLOCKED != p_pcb_old->m_state){
			queue_push(&priority_ready_queue[p_pcb_old->m_priority], p_pcb_old);
		}
	}
	
	process_switch(p_pcb_old);

	atomic(OFF);

	return RTX_OK;
}


/**
 * @brief Change the priority of a process
 * @return RTX_ERR on error and zero on success
 * @param process_id, 	id of the process
 * @param priority,			the priority to change to
 * POST: priority of given process is changed
 */
int k_set_process_priority(int process_id, int priority)
{
	int orig_process_priority; 
	// Check process_id and priority are valid
	if (process_id < 0 || process_id > NUM_TEST_PROCS
		|| priority < HIGH || priority > PRIORITY_NULL)
	{
		return RTX_ERR;
	}
	
	// Null process can only have PRIORITY_NULL
	if(process_id == 0 && priority != PRIORITY_NULL){
		return RTX_ERR;
	}
	
	// Only null process can have PRIORITY_NULL
	if(process_id != 0 && priority == PRIORITY_NULL){
		return RTX_ERR;
	}
	
	atomic(ON);

	orig_process_priority = gp_pcbs[process_id]->m_priority;
	
	// If desired priority is different from process priority
	if(priority != gp_pcbs[process_id]->m_priority){
		
		// Changed process is not current process
		if(gp_current_process != gp_pcbs[process_id]){
			gp_pcbs[process_id]->m_priority = priority;
			
			// if not in ready queue then just return
			if(queue_remove_process(&priority_ready_queue[orig_process_priority] , gp_pcbs[process_id])){
				atomic(OFF);
				return 0;
			}
			
			if(queue_push(&priority_ready_queue[priority], gp_pcbs[process_id])){
				atomic(OFF);
				return RTX_ERR;
			}
			
			// Preemption
			if(gp_pcbs[process_id]->m_priority < gp_current_process->m_priority){
				atomic(OFF);
				return k_release_processor();
			}
			atomic(OFF);
			return 0;
		}else{
			//Current Process is changed process
			gp_current_process->m_priority = priority;
			
			// Preemption
			atomic(OFF);
			return k_release_processor();
		}
	}
	
	atomic(OFF);
	// Else
	return 0;
	
}


/**
 * @brief Get the priority of a process
 * @return priority of the process if process exists, INVALID_PRIORITY(-1) otherwise
 * @param process_id, 	id of the process
 * POST: priority of given process is changed
 */
int k_get_process_priority(int process_id)
{
	// Check process_id validity
	if (process_id < 0 || process_id > NUM_TEST_PROCS)
	{
		return INVALID_PRIORITY;
	}
	
	return gp_pcbs[process_id]->m_priority;
}

// k_alloc_memory calls this if there is no more memory
// this function both PUSHES to QUEUE and SETS STATE
int k_wait_for_memory(void){
	queue_push(&memory_blocked_queue, gp_current_process);
	gp_current_process->m_state = MEM_BLOCKED;
	k_release_processor();
	
	return 0;
}

// k_free_memory calls this
// this function both POPS from QUEUE and SETS STATE
int k_memory_available (void){
	PCB* blocked_process;
	
	if(queue_is_empty(&memory_blocked_queue)){
		return 0;
	}
	
	//else
	blocked_process = queue_pop(&memory_blocked_queue);
	blocked_process->m_state = RDY;
	queue_push(&priority_ready_queue[blocked_process->m_priority], blocked_process);
	// Preemption
	if(blocked_process->m_priority > gp_current_process->m_priority){
		k_release_processor();
	}
	return 0;
}


int k_optionally_preempted_send_message(int destination_id, int sender_id, void* message_envelope, int preempt)
{
	mem_block_header* header = (mem_block_header*)message_envelope;
	PCB* receiver = get_process_from_id(destination_id);
	
	if (receiver == NULL || I_PROCESS_TIMER_ID == destination_id)
	{
		return RTX_ERR;
	}
	

	atomic(ON);

	header->next_message = NULL;
	header->sender_pid = sender_id;
	header->destination_pid = destination_id;
	header->msg_ptr = message_envelope;
	
	
	if (receiver->first == NULL)
	{
		receiver->first = header;
		receiver->last = header;
	}
	else
	{
		receiver->last->next_message = header;
		receiver->last = header;
	}
	
	// set process as ready if it is msg blocked
	if( receiver->m_state == MSG_BLOCKED){
		receiver->m_state = RDY;
		queue_push(&priority_ready_queue[receiver->m_priority], receiver);
		// check priority to determine if preemption is necessary
		if(preempt && receiver->m_priority < gp_current_process->m_priority){
			k_release_processor();
		}
	}
	
	atomic(OFF);

	return 0;
}

/* kernel send message between processes */
int k_send_message(int process_id, void* message_envelope)
{
	return k_optionally_preempted_send_message(process_id,gp_current_process->m_pid, message_envelope, 1);
}

int k_delayed_send(int process_id, void* message_envelope, int delay)
{
	mem_block_header* header = (mem_block_header*)message_envelope;
	PCB* receiver = get_process_from_id(I_PROCESS_TIMER_ID);
	
	if (receiver == NULL || I_PROCESS_TIMER_ID == process_id || delay < 0)
	{
		return RTX_ERR;
	}
	
	
	if(delay == 0){
		return k_send_message(process_id, message_envelope);
	}

	atomic(ON);

	header->next_message = NULL;
	header->sender_pid = gp_current_process->m_pid;
	header->destination_pid = process_id;
	header->msg_ptr = message_envelope;
	header->delay = delay + g_timer_count;
	
	
	if (receiver->first == NULL)
	{
		receiver->first = header;
		receiver->last = header;
	}
	else
	{
		receiver->last->next_message = header;
		receiver->last = header;
	}
	
	atomic(OFF);

	return 0;
}

/* kernel receive message */
void* k_receive_message(int *sender_id)
{
	mem_block_header* header;

	atomic(ON);
	
	// Block and wait
	if(NULL == gp_current_process->first){
		gp_current_process->m_state = MSG_BLOCKED;
		k_release_processor();
	}
		
	// Pop msg from queue once it returns
	header = gp_current_process->first;
	gp_current_process->first = gp_current_process->first->next_message;
	if(NULL == gp_current_process->first){
		gp_current_process->last = NULL;
	}
	
	// Return sender id if possible
	if(NULL != sender_id){
		*sender_id = header->sender_pid;
	}
	
	atomic(OFF);

	return (void*)header;
}


void null_process (void){
	atomic(OFF);
	while(1){
		k_release_processor();
	}
}

void timer_i_process (void){
	PCB * timerProcess= get_process_from_id(I_PROCESS_TIMER_ID);
	PCB * destination = NULL;
	int preempt = 0;
	mem_block_header* header = timerProcess->first;
	mem_block_header* previous = NULL;
	mem_block_header* next = NULL;
	while(header != NULL){
		next = header->next_message;
		if(header->delay <= g_timer_count){
			destination = get_process_from_id(header->destination_pid);
			if(destination->m_priority < gp_current_process->m_priority){
				preempt = 1;
			}
			if(NULL == previous){
				timerProcess->first = next;
			}else{
				previous->next_message = next;
			}
			if(timerProcess->last == header){
				timerProcess->last = previous;
			}
			k_optionally_preempted_send_message(header->destination_pid, header->sender_pid, (void*)header, 0);
		}else{
			previous = header;
		}
		header = next;
	}
	
	if(preempt){
		k_release_processor();
	}
	//initialize_i_process();
	
	//while(1){

		// Do the thing

		//resume_interrupted_process();
	//}
	
#ifdef DEBUG_0
	//printf("in timer i process\n\r");
#endif
	
	
}

void uart_i_process (void){
	void* env = NULL;
#ifdef _DEBUG_HOTKEYS
	int i = 0;
	char buffer[24];
	switch(g_char_in){
		// print ready processes
    case '!'  :
			uart1_put_string("Printing all processes in ready queue\r\n");
			strcpy_(buffer, "pid: xx , priority: x\r\n");
      for(i = 0; i < NUM_TOTAL_PROCS; i++){
				if(gp_pcbs[i]->m_state == RDY || (gp_pcbs[i]->m_state == NEW)){
					buffer[5] = gp_pcbs[i]->m_pid/10 + 48;
					buffer[6] = gp_pcbs[i]->m_pid%10 + 48;
					buffer[20] = gp_pcbs[i]->m_priority + 48;
					uart1_put_string(buffer);
				}
			}
			return;
      break; /* optional */
		
		// print memory-blocked processes
    case '@'  :
			uart1_put_string("Printing all memory-blocked processes\r\n");
			strcpy_(buffer, "pid: xx , priority: x\r\n");
      for(i = 0; i < NUM_TOTAL_PROCS; i++){
				if(gp_pcbs[i]->m_state == MEM_BLOCKED){
					buffer[5] = gp_pcbs[i]->m_pid/10 + 48;
					buffer[6] = gp_pcbs[i]->m_pid%10 + 48;
					buffer[20] = gp_pcbs[i]->m_priority + 48;
					uart1_put_string(buffer);
				}
			}
			return;
      break; /* optional */
		
		// print message-blocked processes
    case '#'  :
			uart1_put_string("Printing all message-blocked processes\r\n");
			strcpy_(buffer, "pid: xx , priority: x\r\n");
      for(i = 0; i < NUM_TOTAL_PROCS; i++){
				if(gp_pcbs[i]->m_state == MSG_BLOCKED){
					buffer[5] = gp_pcbs[i]->m_pid/10 + 48;
					buffer[6] = gp_pcbs[i]->m_pid%10 + 48;
					buffer[20] = gp_pcbs[i]->m_priority + 48;
					uart1_put_string(buffer);
				}
			}
			return;
      break; /* optional */
  
    /* you can have any number of case statements */
    default : /* Optional */
			break;
	}
#endif
	
	env = k_request_memory_block_no_block();
	if(NULL == env){
		return;
	}
	*(int*)(((char*)env)+64) = DEFAULT;
	*(char*)(((char*)env)+68) = g_char_in;
	*(char*)(((char*)env)+69) = '\0';
	
	k_optionally_preempted_send_message(KCD_PROC_ID, I_PROCESS_UART_ID, env, 1);
	//initialize_i_process();
	//while(1){
		// Do the other thing

		//resume_interrupted_process();
	//}
}

void new_process_shim(void){
	// Switch back to null process
	atomic(OFF);
	g_proc_table[gp_current_process->m_pid].mpf_start_pc();
}

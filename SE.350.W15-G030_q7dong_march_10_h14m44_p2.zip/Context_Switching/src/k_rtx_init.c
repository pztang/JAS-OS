/** 
 * @file:   k_rtx_init.c
 * @brief:  Kernel initialization C file
 * @auther: Yiqing Huang
 * @date:   2014/01/17
 */

#include "k_rtx_init.h"

#include "uart_polling.h"

#include "timer.h"
#include "uart.h"
#include "k_memory.h"
#include "k_process.h"

void k_rtx_init(void)
{
        __disable_irq();
 
        memory_init();
        process_init();
				timer_init(0); /* initialize timer 0 */
				uart0_irq_init(); // uart0 interrupt driven, for RTX console

#ifdef _DEBUG_HOTKEYS
				uart1_init();     // uart1 polling, for debugging
#endif
	
        __enable_irq();
	
	/* start the first process */
	
        k_release_processor();
}

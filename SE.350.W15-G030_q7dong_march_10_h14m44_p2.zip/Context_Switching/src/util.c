#include "util.h"

void strcpy_(char* target, char* src)
{
	int index = 0;
	while (*(src + index) != '\0')
	{
		*(target + index) = *(src + index);
		index++;
	}
	*(target + index) = *(src + index);
}

int startswith_(char* str, char* prefix)
{
	int i = 0;
	while (*(str + i) != '\0' && *(prefix + i) != '\0')
	{
		if (*(str + i) != *(prefix + i))
		{
			return 0;
		}
		i++;
	}
	return 1;
}

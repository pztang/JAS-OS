/**
 * @file:   usr_proc.c
 * @brief:  Two user processes: proc1 and proc2
 * @author: Yiqing Huang
 * @date:   2014/01/17
 * NOTE: Each process is in an infinite loop. Processes never terminate.
 *
 * Test Cases:
 * NOTE: If you are a TA please do not read the following, these test cases are for internal use only
 * not for demo purposes. Please adjust macros and uncomment code as fit
 *
 * 1. Release Test - Two processes calling processor release, kernel should alternate between two processes
 * 2. InfMemReq Test - have a process request memory in an infinite loop while printing the number of iterations (should stop sometime on success)
 * 3. Unblock Test - Process 1 requests absolutely all the memory blocks, then voluntarily releases processor.
 *                   Process 2 requests memory, gets blocked.
 *                   Process 1 releases some memory, then voluntarily releases processor.
 *                   Process 2 should resume and obtain the memory he requested.
 * 4. Preemption Test - Process 1 elevates priority of process 2. Function should not return
 *											Process 2 should run infinitely even if it calls release processor.
 * 5. Preemption Unblock Test - combination of test cases 3 and 4
 *                              Process 1 requests absolutely all the memory blocks and then release processor
 *                              Process 2 requests memory, gets blocked
 *                              Process 1 changes process 2's priority to higher than that of Process 1
 *                              
 */

#include "rtx.h"
#include "uart_polling.h"
#include "usr_proc.h"

//#define SANITY_TEST

#ifdef DEBUG_0
#include "printf.h"
#endif /* DEBUG_0 */

/* initialization table item */
PROC_INIT g_test_procs[NUM_TEST_PROCS];

void set_test_procs() {
	int i;
	for( i = 0; i < NUM_TEST_PROCS; i++ ) {
		g_test_procs[i].m_pid=(U32)(i+1);
		g_test_procs[i].m_priority=LOWEST;
		g_test_procs[i].m_stack_size=0x200;
	}
  
	g_test_procs[0].mpf_start_pc = &proc1;
	g_test_procs[1].mpf_start_pc = &proc2;
	g_test_procs[2].mpf_start_pc = &proc3;
	g_test_procs[3].mpf_start_pc = &proc4;
	g_test_procs[4].mpf_start_pc = &proc5;
	g_test_procs[5].mpf_start_pc = &proc6;
}



typedef struct msgbuf_struct__
{
	int mtype;
	char mtext[40];
} msgbuf;

msgbuf* get_buffer_start(int* memory_block)
{
	return (msgbuf*)(((char*)memory_block) + 64);
}

void strcpy(char* target, char* src)
{
	int index = 0;
	while (*(src + index) != '\0')
	{
		*(target + index) = *(src + index);
		index++;
	}
	*(target + index) = *(src + index);
	
}

#if defined(SANITY_TEST) || ! defined(_DEBUG_HOTKEYS)
//Demo Test Set (6 test cases)
void proc1(void)
{
	int successes = 0;
	int sender = 0;
	int* memory_block = NULL;
	msgbuf* otherProcMsg = NULL;
	int* env = NULL;
	msgbuf* msg = NULL;
	
	
	env = (int*)request_memory_block();
	if(env != NULL){
		msg = get_buffer_start(env);
		msg->mtype = DEFAULT;
		strcpy(msg->mtext, "\n\rG030_test: START\n\r");
		send_message(CRT_PROC_ID, env);
		
		env = (int*)request_memory_block();
		msg = get_buffer_start(env);
		msg->mtype = DEFAULT;
		strcpy(msg->mtext, "G030_test: total 6 tests\n\r");
		send_message(CRT_PROC_ID, env);
		
		
		
		//Test case 1: memory test
		env = (int*)request_memory_block();
		msg = get_buffer_start(env);
		msg->mtype = DEFAULT;
		memory_block = (int*)request_memory_block();
		if(NULL == memory_block){
			strcpy(msg->mtext, "G030_test: test 1 FAIL\n\r");
		}else{
			if(RTX_ERR == release_memory_block(memory_block)){
				strcpy(msg->mtext, "G030_test: test 1 FAIL\n\r");
			}else{
				strcpy(msg->mtext, "G030_test: test 1 OK\n\r");
				successes++;
			}
		}
		send_message(CRT_PROC_ID, env);
		
		//Test case 2: Get Priority Test
		env = (int*)request_memory_block();
		msg = get_buffer_start(env);
		msg->mtype = DEFAULT;
		if(LOWEST == get_process_priority(1)){
			strcpy(msg->mtext, "G030_test: test 2 OK\n\r");
			successes++;
		}else{
			strcpy(msg->mtext, "G030_test: test 2 FAIL\n\r");
		}
		send_message(CRT_PROC_ID, env);
		
		//Test case 3: Set Priority Test
		env = (int*)request_memory_block();
		msg = get_buffer_start(env);
		msg->mtype = DEFAULT;
		if(RTX_ERR == set_process_priority(1, HIGH)){
			strcpy(msg->mtext, "G030_test: test 3 FAIL\n\r");
		}else{
			if(HIGH == get_process_priority(1)){
				// invalid pid
				if(RTX_ERR == set_process_priority(16, HIGH)){
					//invalid priority
					if(RTX_ERR == set_process_priority(1, 7)){
						strcpy(msg->mtext, "G030_test: test 3 OK\n\r");
						successes++;
					}	else{
						strcpy(msg->mtext, "G030_test: test 3 FAIL\n\r");
					}
				}else{
					strcpy(msg->mtext, "G030_test: test 3 FAIL\n\r");
				}
			}else{
				strcpy(msg->mtext, "G030_test: test 3 FAIL\n\r");
			}
		}
		send_message(CRT_PROC_ID, env);
		
		//Test case 4: Release Processor Test
		env = (int*)request_memory_block();
		msg = get_buffer_start(env);
		msg->mtype = DEFAULT;
		if(RTX_ERR == release_processor()){
			strcpy(msg->mtext, "G030_test: test 4 FAIL\n\r");
		}else{
			strcpy(msg->mtext, "G030_test: test 4 OK\n\r");
			successes++;
		}
		send_message(CRT_PROC_ID, env);
	
		//Test case 5: Send Message Test
		env = (int*)request_memory_block();
		msg = get_buffer_start(env);
		msg->mtype = DEFAULT;
		memory_block = (int*)request_memory_block();
		if(NULL == memory_block){
			strcpy(msg->mtext, "G030_test: test 5 FAIL\n\r");
		}else{
			otherProcMsg = get_buffer_start(memory_block);
			otherProcMsg->mtype = DEFAULT;
			if(RTX_ERR == send_message(2, memory_block)){
				strcpy(msg->mtext, "G030_test: test 5 FAIL\n\r");
			}else{
				memory_block = receive_message(&sender);
				if(NULL == memory_block){
					strcpy(msg->mtext, "G030_test: test 5 FAIL\n\r");
				}else{
					if(2 == sender){
						otherProcMsg = get_buffer_start(memory_block);
						if(otherProcMsg->mtext[0] == 'Y'){
							if(RTX_ERR == release_memory_block(memory_block)){
								strcpy(msg->mtext, "G030_test: test 5 FAIL\n\r");
							}else{
								strcpy(msg->mtext, "G030_test: test 5 OK\n\r");
								successes++;
							}
						}else{
							strcpy(msg->mtext, "G030_test: test 5 FAIL\n\r");
							release_memory_block(memory_block);
						}	
					}else{
						strcpy(msg->mtext, "G030_test: test 5 FAIL\n\r");
						release_memory_block(memory_block);
					}					
				}
			}
		}
		send_message(CRT_PROC_ID, env);
		
		//Test case 5: Delayed Send Test
		env = (int*)request_memory_block();
		msg = get_buffer_start(env);
		msg->mtype = DEFAULT;
		memory_block = (int*)request_memory_block();
		if(NULL == memory_block){
			strcpy(msg->mtext, "G030_test: test 6 FAIL\n\r");
		}else{
			otherProcMsg = get_buffer_start(memory_block);
			otherProcMsg->mtype = DEFAULT;
			if(RTX_ERR == delayed_send(2, memory_block , 1000)){
				strcpy(msg->mtext, "G030_test: test 6 FAIL\n\r");
			}else{
				memory_block = receive_message(&sender);
				if(NULL == memory_block){
					strcpy(msg->mtext, "G030_test: test 6 FAIL\n\r");
				}else{
					if(2 == sender){
						otherProcMsg = get_buffer_start(memory_block);
						if(otherProcMsg->mtext[0] == 'Y'){
							if(RTX_ERR == release_memory_block(memory_block)){
								strcpy(msg->mtext, "G030_test: test 6 FAIL\n\r");
							}else{
								strcpy(msg->mtext, "G030_test: test 6 OK\n\r");
								successes++;
							}
						}else{
							strcpy(msg->mtext, "G030_test: test 6 FAIL\n\r");
							release_memory_block(memory_block);
						}		
					}else{
						strcpy(msg->mtext, "G030_test: test 6 FAIL\n\r");
						release_memory_block(memory_block);
					}
				}
			}
		}
		send_message(CRT_PROC_ID, env);
		
		env = (int*)request_memory_block();
		msg = get_buffer_start(env);
		msg->mtype = DEFAULT;
		strcpy(msg->mtext, "G030_test: x/6 tests OK\n\r");
		msg->mtext[11] = successes+48;
		send_message(CRT_PROC_ID, env);
		
		env = (int*)request_memory_block();
		msg = get_buffer_start(env);
		msg->mtype = DEFAULT;
		strcpy(msg->mtext, "G030_test: x/6 tests FAIL\n\r");
		msg->mtext[11] = 6-successes+48;
		send_message(CRT_PROC_ID, env);
		
		
		env = (int*)request_memory_block();
		msg = get_buffer_start(env);
		msg->mtype = DEFAULT;
		strcpy(msg->mtext, "G030_test: END\n\r");
		send_message(CRT_PROC_ID, env);
	}
	while ( 1) {
		release_processor();
	}
}
void proc2(void)
{
	int sender_id = 0;
	msgbuf* msg = NULL;
	int* env = NULL;

	env = NULL;
	msg = NULL;

	while (1)
	{
		env = receive_message(&sender_id);
		msg = get_buffer_start(env);
		msg->mtext[0] = 'Y';
		send_message(sender_id, env);
		// while (msg->mtext[i] != '\0')
		// {
		// 	c = msg->mtext[i];
		// 	#ifdef DEBUG_0
		// 	#endif
		// 	i++;
		// }
	}
}

void proc3 (void){
	while(1){
		release_processor();
	}
}

void proc4 (void){
	while(1){
		release_processor();
	}
}

void proc5 (void){
	while(1){
		release_processor();
	}
}

void proc6 (void){
	while(1){
		release_processor();
	}
}

#endif
#if ! defined(SANITY_TEST) && defined(_DEBUG_HOTKEYS)
void proc1 (void){
	while(1){
		request_memory_block();
	}
}

void proc2 (void){
	while(1){
		request_memory_block();
	}
}

void proc3 (void){
	while(1){
		request_memory_block();
	}
}

void proc4 (void){
	while(1){
		request_memory_block();
	}
}

void proc5 (void){
	while(1){
		request_memory_block();
	}
}

void proc6 (void){
	while(1){
		request_memory_block();
	}
}

#endif
// Test Case 1 : 2 processes
/**************************************
***************************************
**************************************/


//@brief: a process that prints five uppercase letters and then yields the cpu.
/*void proc1(void)
{
	int i = 0;
	int ret_val = 10;
	while ( 1) {
		if ( i != 0 && i%5 == 0 ) {
			uart0_put_string("\n\r");
			ret_val = release_processor();
#ifdef DEBUG_0
			printf("proc1: ret_val=%d\n", ret_val);
#endif 
		}
		uart0_put_char('A' + i%26);
		i++;
	}
}

// @brief: a process that prints five numbers and then yields the cpu.
void proc2(void)
{
	int i = 0;
	int ret_val = 20;
	while ( 1) {
		if ( i != 0 && i%5 == 0 ) {
			uart0_put_string("\n\r");
			ret_val = release_processor();
#ifdef DEBUG_0
			printf("proc2: ret_val=%d\n", ret_val);
#endif  
		}
		uart0_put_char('0' + i%10);
		i++;
	}
}

void proc3 (void){
	while(1){
		release_processor();
	}
}

void proc4 (void){
	while(1){
		release_processor();
	}
}

void proc5 (void){
	while(1){
		release_processor();
	}
}

void proc6 (void){
	while(1){
		release_processor();
	}
}*/

// Test Case 2 : 3 process
/**************************************
***************************************
**************************************/

/*void proc1(void){
	int i = 1;
	int* memory_block;
	while(1){
		memory_block = (int*)request_memory_block();
#ifdef DEBUG_0
		printf("proc3: allocating memory block: %d at address: 0x%x\n", i++, memory_block);
#endif 
	}
	
}
void proc2 (void){
	while(1){
		release_processor();
	}
}

void proc3 (void){
	while(1){
		release_processor();
	}
}

void proc4 (void){
	while(1){
		release_processor();
	}
}

void proc5 (void){
	while(1){
		release_processor();
	}
}

void proc6 (void){
	while(1){
		release_processor();
	}
}*/

// Test Case 3: 3 processes
/**************************************
***************************************
**************************************/
/*
void proc1(void)
{
	int i = 0;
	int* memory_block;
	for (i = 0; i<112; i++){
		memory_block = (int*)request_memory_block();
	}
	
	release_processor();
#ifdef DEBUG_0
		printf("returned to proc1: releasing memory\n");
#endif 
	release_memory_block(memory_block);
	release_processor();
	
	while(1){
#ifdef DEBUG_0
		printf("ERROR: in proc1: should not be here\n");
#endif 
	}
}

// @brief: a process that prints five numbers and then yields the cpu.
void proc2(void)
{
	int* memory_block;
	
#ifdef DEBUG_0
		printf("in proc2: requesting memory; should proceed to proc1\n");
#endif 
	
	memory_block = request_memory_block();
	
#ifdef DEBUG_0
		printf("in proc2: if was previously in proc1, then SUCCESS\n");
#endif 
	while ( 1) {
		;
	}
}

void proc3 (void){
	while(1){
		release_processor();
	}
}

void proc4 (void){
	while(1){
		release_processor();
	}
}

void proc5 (void){
	while(1){
		release_processor();
	}
}

void proc6 (void){
	while(1){
		release_processor();
	}
}
*/
// Test Case 4: 2 processes
/**************************************
***************************************
**************************************/
/*
 void proc1(void)
{
#ifdef DEBUG_0
		printf("in proc1: elevating proc2 priority\n");
#endif 
	set_process_priority(2, HIGH);
	
	while(1){
#ifdef DEBUG_0
		printf("ERROR: in proc1: should not be here\n");
#endif 
	}
}

// @brief: a process that prints five numbers and then yields the cpu.
void proc2(void)
{
	
#ifdef DEBUG_0
		printf("in proc2: preemption test: SUCCESSFUL\n");
#endif 
	
	while ( 1) {
		release_processor();
	}
}
void proc3 (void){
	while(1){
		release_processor();
	}
}

void proc4 (void){
	while(1){
		release_processor();
	}
}

void proc5 (void){
	while(1){
		release_processor();
	}
}

void proc6 (void){
	while(1){
		release_processor();
	}
}

*/
// Test Case 5: 3 processes
/**************************************
***************************************
**************************************/
/*
void proc1(void)
{
	int i = 0;
	int* memory_block;
	for (i = 0; i<112; i++){
		memory_block = (int*)request_memory_block();
	}
	
	release_processor();
#ifdef DEBUG_0
		printf("returned to proc1: releasing memory\n");
#endif 
	release_memory_block(memory_block);
	set_process_priority(2, HIGH);
	
	while(1){
#ifdef DEBUG_0
		printf("ERROR: in proc1: should not be here\n");
#endif 
	}
}

// @brief: a process that prints five numbers and then yields the cpu.
void proc2(void)
{
	int* memory_block;
	
#ifdef DEBUG_0
		printf("in proc2: requesting memory; should proceed to proc1\n");
#endif 
	
	memory_block = request_memory_block();
	
#ifdef DEBUG_0
		printf("in proc2: if was previously in proc1, then SUCCESS\n");
#endif 
	while ( 1) {
		release_processor();
	}
}

void proc3 (void){
	while(1){
		release_processor();
	}
}

void proc4 (void){
	while(1){
		release_processor();
	}
}

void proc5 (void){
	while(1){
		release_processor();
	}
}

void proc6 (void){
	while(1){
		release_processor();
	}
}*/
// Test Case 6: 6 processes
/**************************************
***************************************
**************************************/

/*

typedef struct msgbuf_struct__
{
	int mtype;
	char mtext[50];
} msgbuf;

msgbuf* get_buffer_start(int* memory_block)
{
	return (msgbuf*)(((char*)memory_block) + 64);
}

void strcpy(char* target, char* src)
{
	int index = 0;
	while (*(src + index) != '\0')
	{
		*(target + index) = *(src + index);
		index++;
	}
	*(target + index) = *(src + index);
	
}

void proc1(void)
{
	int sender_id = 0;
	msgbuf* msg = NULL;
	int* out_msg1_block = NULL;
	int* out_msg2_block = NULL;
	msgbuf* out_msg1 = NULL;
	msgbuf* out_msg2 = NULL;
	
	#ifdef DEBUG_0
		printf("\r\rStarting in process 1\r");
	#endif 
	
	set_process_priority(1, MEDIUM);
	msg = (msgbuf*)(((char*)receive_message(&sender_id)) + 64);
	
	#ifdef DEBUG_0
		printf("Back to process 1\r");
		printf(msg->mtext);
	#endif 
	
	out_msg1_block = request_memory_block();
	out_msg2_block = request_memory_block();
	
	out_msg1 = get_buffer_start(out_msg1_block);
	out_msg2 = get_buffer_start(out_msg2_block);
	
	strcpy(out_msg1->mtext, "message 1\r");
	strcpy(out_msg2->mtext, "message 2\r");
	
	send_message(2, out_msg1_block);
	send_message(2, out_msg2_block);
	
	set_process_priority(2, HIGH);
	
	while ( 1) {
		release_processor();
	}
}

// @brief: a process that prints five numbers and then yields the cpu.
void proc2(void)
{
	int* memory_block = NULL;
	msgbuf* buffer = NULL;
	msgbuf* msg1 = NULL;
	msgbuf* msg2 = NULL;
	memory_block = request_memory_block();
	
	#ifdef DEBUG_0
		printf("In process 2\r");
	#endif 
	
	buffer = (msgbuf*)(((char*)memory_block) + 64);
	//buffer->mtext = "Hello.\n";
	strcpy(buffer->mtext, "Initial message!\r");
	
	send_message(1, memory_block);
	
	
	#ifdef DEBUG_0
		printf("Back in process 2 since it got set to a higher priority\r");
	#endif 
	
	msg1 = get_buffer_start(receive_message(NULL));
	msg2 = get_buffer_start(receive_message(NULL));
	
	#ifdef DEBUG_0
		printf(msg1->mtext);
		printf(msg2->mtext);
	#endif 

	while ( 1) {
		release_processor();
	}
}

void proc3 (void){
	while(1){
		release_processor();
	}
}

void proc4 (void){
	while(1){
		release_processor();
	}
}

void proc5 (void){
	while(1){
		release_processor();
	}
}

void proc6 (void){
	while(1){
		release_processor();
	}
}*/



// Test Case 7: 6 processes
/**************************************
***************************************
**************************************/



/*void proc1(void)
{
	int sender_id = 0;
	msgbuf* msg = NULL;
	int* env = NULL;
	int i = 0;
	char c = '\0';

	env = (int*) request_memory_block();
	msg = get_buffer_start(env);
	msg->mtype = KCD_REG;
	strcpy(msg->mtext, "foo");
	send_message(KCD_PROC_ID, env);
	
	env = (int*) request_memory_block();
	msg = get_buffer_start(env);
	msg->mtype = KCD_REG;
	strcpy(msg->mtext, "bar");
	send_message(KCD_PROC_ID, env);
	
	set_process_priority(1, MEDIUM);

	env = NULL;
	msg = NULL;

	while (1)
	{
		env = receive_message(&sender_id);
		msg = get_buffer_start(env);
		i = 0;
		printf("\r\nIn Proc 1\r\n%s\r\n", msg->mtext);
		// while (msg->mtext[i] != '\0')
		// {
		// 	c = msg->mtext[i];
		// 	#ifdef DEBUG_0
		// 	#endif
		// 	i++;
		// }
	}
	
	while ( 1) {
		release_processor();
	}
}

// @brief: a process that prints five numbers and then yields the cpu.
void proc2(void)
{
	int sender_id = 0;
	msgbuf* msg = NULL;
	int* env = NULL;
	int i = 0;
	char c = '\0';

	env = (int*) request_memory_block();
	msg = get_buffer_start(env);
	msg->mtype = KCD_REG;
	strcpy(msg->mtext, "foobar");
	send_message(KCD_PROC_ID, env);
	
	set_process_priority(1, MEDIUM);

	env = NULL;
	msg = NULL;

	while (1)
	{
		env = receive_message(&sender_id);
		msg = get_buffer_start(env);
		i = 0;
		printf("\r\nIn Proc 2\r\n%s\r\n", msg->mtext);
		// while (msg->mtext[i] != '\0')
		// {
		// 	c = msg->mtext[i];
		// 	#ifdef DEBUG_0
		// 	#endif
		// 	i++;
		// }
	}
	
	while(1){
		release_processor();
	}
}

void proc3 (void){
	while(1){
		release_processor();
	}
}

void proc4 (void){
	while(1){
		release_processor();
	}
}

void proc5 (void){
	while(1){
		release_processor();
	}
}

void proc6 (void){
	while(1){
		release_processor();
	}
}*/

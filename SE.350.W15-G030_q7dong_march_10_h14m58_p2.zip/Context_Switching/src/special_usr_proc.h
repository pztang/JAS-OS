#ifndef SPECIAL_USR_PROC_H_
#define SPECIAL_USR_PROC_H_


#define SET_PRIORITY_PROC_ID		10
#define WALL_CLOCK_PROC_ID			11
#define KCD_PROC_ID							12
#define CRT_PROC_ID							13

void set_special_usr_procs(void);
void nullProcess(void);
void a(void);
void b(void);
void c(void);
void setPriorityProc(void);
void wallClockProc(void);
void kcdProc(void);
void crtProc(void);

#endif /* USR_PROC_H_ */

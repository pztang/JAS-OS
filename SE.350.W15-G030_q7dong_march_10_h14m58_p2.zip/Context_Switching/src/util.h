#ifndef UTIL_H_
#define UTIL_H_

void strcpy_(char* target, char* src);
int startswith_(char* str, char* prefix);

#endif

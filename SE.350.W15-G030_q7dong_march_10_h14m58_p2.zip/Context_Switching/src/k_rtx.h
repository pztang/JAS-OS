/** 
 * @file:   k_rtx.h
 * @brief:  kernel deinitiation and data structure header file
 * @auther: Yiqing Huang
 * @date:   2014/01/17
 */
 
#ifndef K_RTX_H_
#define K_RTX_H_

/*----- Definitations -----*/

#define RTX_ERR (-1)
#define RTX_OK  0

/* ATOMIC Levels! */
#define ON 1
#define OFF 0

#define NULL 0
#define NUM_TOTAL_PROCS 16
#define NUM_TEST_PROCS 6
#define NUM_STRESS_PROCS 3

/* Process Priority. The bigger the number is, the lower the priority is*/
#define INVALID_PRIORITY	(-1)
#define HIGH    					0
#define MEDIUM  					1
#define LOW     					2
#define LOWEST  					3
#define PRIORITY_NULL			4
#define PRIORITY_COUNT		4


#define DEFAULT 0
#define KCD_REG 1

//#ifdef DEBUG_0
//#define USR_SZ_STACK 0x200         /* user proc stack size 512B   */
//#else
//#define USR_SZ_STACK 0x100         /* user proc stack size 218B  */
//#endif /* DEBUG_0 */

#define MAX_STACK_SZ 0x400				 /* Maximum stack size each process can get */
#define MEM_SLICE_SZ 0x10					 /* Size of a single slice of heap (including header) */

/*----- Types -----*/
typedef unsigned char U8;
typedef unsigned int U32;

/* process states, note we only assume three states in this example */
typedef enum {NEW = 0, RDY, MEM_BLOCKED, MSG_BLOCKED, INTERRUPT , RUN} PROC_STATE_E;  

/*
	Message envelope.
	A single node in the linked list of envelopes.
*/
typedef struct mem_block_struct__
{
	struct mem_block_struct__* next_message;
	U32 sender_pid;
	U32 destination_pid;
	void* msg_ptr;
	int delay;
} mem_block_header;

/*
  PCB data structure definition.
  You may want to add your own member variables
  in order to finish P1 and the entire project 
*/
typedef struct pcb 
{ 
	//struct pcb *mp_next;  /* next pcb, not used in this example */  
	U32 *mp_sp;		/* stack pointer of the process */
	U32 m_pid;		/* process id */
	U8 m_priority; /* priority */
	PROC_STATE_E m_state;   /* state of the process */
	int atomic_level; /* Interrupt disable counter */
	mem_block_header* first;		/* Points to the first message in the queue */
	mem_block_header* last;		/* Points to the last message in the queue */

} PCB;

/* initialization table item */
typedef struct proc_init
{	
	int m_pid;	        /* process id */ 
	int m_priority;         /* initial priority, not used in this example. */ 
	int m_stack_size;       /* size of stack in words */
	void (*mpf_start_pc) ();/* entry point of the process */    
} PROC_INIT;

#endif // ! K_RTX_H_

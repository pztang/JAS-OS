#include <LPC17xx.h>
#include <system_LPC17xx.h>
#include "rtx.h"
#include "uart_polling.h"
#include "special_usr_proc.h"
#include "uart.h"
#include "util.h"

#ifdef DEBUG_0
#include "printf.h"
#endif /* DEBUG_0 */

#define MAX_INPUT_LENGTH 40
#define MAX_CMD_LENGTH 10
#define PROMPT_LENGTH 10

extern uint8_t* gp_buffer;
extern uint8_t g_send_char;
extern LPC_TIM_TypeDef *pTimer1;

/* initialization table item */
PROC_INIT g_stress_procs[NUM_STRESS_PROCS];
PROC_INIT g_set_priority;
PROC_INIT g_wall_clock;
PROC_INIT g_kcd;
PROC_INIT g_crt;

int envCount = 0;

typedef struct msgbuf_struct__
{
	int mtype;
	char mtext[50];
} msgbuf;

typedef struct commandSigNode_struct__
{
	struct commandSigNode_struct__* pNext;
	char mtext[MAX_INPUT_LENGTH + 1];
	int command_length;
	int sender;

} CommandSigNode;


msgbuf* get_buffer_start_(int* memory_block)
{
	return (msgbuf*)(((char*)memory_block) + 64);
}

int* get_envelope_start(msgbuf* msg)
{
	return (int*)(((char*)msg) - 64);
}

void print_to_crt(char* str)
{
	int* env;
	msgbuf* msg;
	env = (int*)request_memory_block();
	msg = get_buffer_start_(env);
	msg->mtype = DEFAULT;
	strcpy_(msg->mtext, str);
	send_message(CRT_PROC_ID, env);
}

void set_special_usr_procs() {
	int i;
	for( i = 0; i < NUM_STRESS_PROCS; i++ ) {
		g_stress_procs[i].m_pid=(U32)(i+7);
		g_stress_procs[i].m_priority=LOWEST;
		g_stress_procs[i].m_stack_size=0x200;
	}
	// C needs higher priority than A
	g_stress_procs[0].m_priority=LOW;
  
	g_stress_procs[0].mpf_start_pc = &a;
	g_stress_procs[1].mpf_start_pc = &b;
	g_stress_procs[2].mpf_start_pc = &c;
	
	g_set_priority.m_pid = (U32) SET_PRIORITY_PROC_ID;
	g_set_priority.m_priority = HIGH;
	g_set_priority.m_stack_size = 0x200;
	g_set_priority.mpf_start_pc = &setPriorityProc;
	
	
	g_wall_clock.m_pid = (U32) WALL_CLOCK_PROC_ID;
	g_wall_clock.m_priority = HIGH;
	g_wall_clock.m_stack_size = 0x200;
	g_wall_clock.mpf_start_pc = &wallClockProc;
	
	g_kcd.m_pid = (U32) KCD_PROC_ID;
	g_kcd.m_priority = HIGH;
	g_kcd.m_stack_size = 0x200;
	g_kcd.mpf_start_pc = &kcdProc;
	
	g_crt.m_pid = (U32) CRT_PROC_ID;
	g_crt.m_priority = HIGH;
	g_crt.m_stack_size = 0x200;
	g_crt.mpf_start_pc = &crtProc;
}


void a(void){
	int num = 0;
	int sender = 0;
	int* env = NULL;
	msgbuf* msg = NULL;
	env = (int*)request_memory_block();
	msg = get_buffer_start_(env);
	msg->mtype = KCD_REG;	
	strcpy_(msg->mtext, "%Z");
	send_message(KCD_PROC_ID, env);

	env = NULL;
	msg = NULL;
	while(1){
		env = receive_message(&sender);
		msg = get_buffer_start_(env);
		if('%' == msg->mtext[0] && 'Z' == msg->mtext[1]){
			release_memory_block(env);
			break;
		}else{
			release_memory_block(env);
		}
	}

	num = 0;

	while(1){
		
			env = (int*)request_memory_block();
			envCount++;
			msg = get_buffer_start_(env);
			msg->mtype = COUNT_REPORT;
			*((int*) msg->mtext) = num;
			send_message(8, env);
			num++;
			release_processor();
	}
}

void b(void){
	int* env = NULL;
	int sender = 0;	
	while(1){
		env = receive_message(&sender);
		// forward to process C
		send_message(9, env);
	}
}

void c(void){
	int* env = NULL;
	msgbuf* msg = NULL;
	int* hib_env = NULL;
	msgbuf* hib_msg = NULL;
	int sender = 0;
	CommandSigNode* commandListFront = NULL;
	CommandSigNode* commandListBack = NULL;

	env = NULL;
	msg = NULL;

	while(1){
		// if queue empty
		if(NULL == commandListFront){
			env = receive_message(&sender);
		}else{
			// else take front of queue
			env = get_envelope_start((msgbuf*)commandListFront);
			commandListFront = commandListFront->pNext;
		}

		msg = get_buffer_start_(env);

		if(COUNT_REPORT == msg->mtype){
			if(*((int*) msg->mtext) % 20 == 0){
				strcpy_(msg->mtext, "Process C\n\r");
				send_message(CRT_PROC_ID, env);

				//hibernate
				hib_env = request_memory_block();
				hib_msg = get_buffer_start_(hib_env);
				hib_msg->mtype = WAKE_UP_10;
				delayed_send(9, hib_env ,10000);
				while(1){
					env = receive_message(&sender);
					msg = get_buffer_start_(env);
					if(WAKE_UP_10 == msg->mtype){
						break;
					}else{
						if(commandListFront == NULL){
							commandListFront = (CommandSigNode*) msg;
							commandListBack = commandListFront;
							commandListFront->pNext = NULL;
						}else{
							commandListBack->pNext = (CommandSigNode*) msg;
							commandListBack = (CommandSigNode*) msg;
							commandListBack->pNext = NULL;
						}
					}
				}

				
			}
		}

		release_memory_block(env);
		envCount--;
		release_processor();
	}
}


int read_next_number(char* str, int* pos)
{
	int i = 0;
	int result = 0;
	char c;

	int found_token = 0;

	int begin = *pos;
	int end = *pos + 1;


	for (i = (*pos); str[i] != '\0'; i++)
	{
		c = str[i];
		
		if (c != ' ' && c != '\t')
		{
			end = i + 1;
			if (!found_token)
			{
				begin = i;
				found_token = 1;
			}
		}
		else
		{
			if (found_token)
				break;
		}
	}

	(*pos) = end;

	if (found_token)
	{
		for (i = begin; i < end; i++)
		{
			c = str[i];
			if (48 <= c && c <= 57)
			{
				result *= 10;
				result += (int)(c - 48);
			}
			else
			{
				return -1;
			}
		}
		return result;
	}
	else
	{
		return -1;
	}
}

void setPriorityProc(void){
	int pos;
	int target_pid;
	int target_priority;
	int result;

	int sender = 0;
	int* env = NULL;
	msgbuf* msg = NULL;
	env = (int*)request_memory_block();
	msg = get_buffer_start_(env);
	msg->mtype = KCD_REG;
	strcpy_(msg->mtext, "%C");
	send_message(KCD_PROC_ID, env);

	env = NULL;
	msg = NULL;

	while(1){
		env = receive_message(&sender);
		msg = get_buffer_start_(env);

		// %C 13 1
		// %C 3 1
		pos = 0;
		read_next_number(msg->mtext, &pos);
		target_pid = read_next_number(msg->mtext, &pos);
		target_priority = read_next_number(msg->mtext, &pos);

		if (set_process_priority(target_pid, target_priority) == RTX_ERR )
		{
			strcpy_(msg->mtext, "Invalid input for priority change.\n\r");
		}
		else
		{
			strcpy_(msg->mtext, "Successfully changed priority.\n\r");
		}

		msg->mtype = DEFAULT;
		send_message(CRT_PROC_ID, env);

		env = NULL;
		msg = NULL;
	}
}

void wallClockProc(void){
	int sender = 0;
	int time = 0;
	int display = 0;
	int* env = NULL;
	int i = 0;
	msgbuf* msg = NULL;
	
	int* out_env = NULL;
	msgbuf* out_msg = NULL;

	env = (int*) request_memory_block();
	msg = get_buffer_start_(env);
	msg->mtype = KCD_REG;
	strcpy_(msg->mtext, "%WS");
	send_message(KCD_PROC_ID, env);

	env = (int*) request_memory_block();
	msg = get_buffer_start_(env);
	msg->mtype = KCD_REG;
	strcpy_(msg->mtext, "%WR");
	send_message(KCD_PROC_ID, env);

	env = (int*) request_memory_block();
	msg = get_buffer_start_(env);
	msg->mtype = KCD_REG;
	strcpy_(msg->mtext, "%WT");
	send_message(KCD_PROC_ID, env);
	
	env = (int*) request_memory_block();
	msg = get_buffer_start_(env);
	delayed_send(WALL_CLOCK_PROC_ID, env ,1000);

	env = NULL;
	msg = NULL;

	while(1){
		env = receive_message(&sender);
		msg = get_buffer_start_(env);
		if (sender == WALL_CLOCK_PROC_ID)
		{

			if (display)
			{
				out_env = (int*)request_memory_block();
				out_msg = get_buffer_start_(out_env);
				i = 0;
				out_msg->mtext[i++] = '\n';
				out_msg->mtext[i++] = '\r';
				out_msg->mtext[i++] = (char)(time / 3600 % 60 / 10 + 48);
				out_msg->mtext[i++] = (char)(time / 3600 % 10 + 48);
				out_msg->mtext[i++] = ':';
				out_msg->mtext[i++] = (char)(time / 60 % 60 / 10 + 48);
				out_msg->mtext[i++] = (char)(time / 60 % 10 + 48);
				out_msg->mtext[i++] = ':';
				out_msg->mtext[i++] = (char)(time % 60 / 10 + 48);
				out_msg->mtext[i++] = (char)(time % 10 + 48);
				out_msg->mtext[i++] = '\0';
				send_message(CRT_PROC_ID, out_env);
				out_env = NULL;
				out_msg = NULL;
				time++;
				
				if(time >= 24*60*60){
					time = 0;
				}
			}
			// Since reuse memory block
			delayed_send(WALL_CLOCK_PROC_ID, env ,1000);
		}
		else if (sender == KCD_PROC_ID)
		{
			if (startswith_(msg->mtext, "%WS"))
			{
				i = 0;
				while (msg->mtext[i++] != '\0') {}
				if (i >= 12)
				{
					//printf("\r\n%d, %d, %d, %d, %d, %d\r\n", (msg->mtext[4] - 48) * 3600 * 10, (msg->mtext[5] - 48) * 3600, (msg->mtext[7] - 48) * 60 * 10, (msg->mtext[8] - 48) * 60, (msg->mtext[10] - 48) * 10, (msg->mtext[11] - 48));
					time = 
						(msg->mtext[4] - 48) * 3600 * 10 +
						(msg->mtext[5] - 48) * 3600 +
						(msg->mtext[7] - 48) * 60 * 10 +
						(msg->mtext[8] - 48) * 60 +
						(msg->mtext[10] - 48) * 10 +
						(msg->mtext[11] - 48);
					
					if(time >= 24*60*60){
						time = 0;
					}
					display = 1;
				} else{
					strcpy_(msg->mtext, "\n\rInvalid %WS Command input length");
					send_message(CRT_PROC_ID, env);
				}
			}
			else if (startswith_(msg->mtext, "%WR"))
			{
				display = 1;
				time = 0;
			
				// free the memory block
				release_memory_block(env);
			}
			else if (startswith_(msg->mtext, "%WT"))
			{
				display = 0;
			
				// free the memory block
				release_memory_block(env);
			}
		}
		env = NULL;
		msg = NULL;
	}
}




void kcdProc(void){

	int i = 0;
	int sent = 0;
	int* env = NULL;
	msgbuf* msg = NULL;
	int* out_env = NULL;
	msgbuf* out_msg = NULL;
	int sender = 0;
	char currentLine[MAX_INPUT_LENGTH + 1];
	int current_char_index = 0;
	char letter;
	int found = 0;
	CommandSigNode* commandListFront = NULL;
	CommandSigNode* commandListBack = NULL;
	CommandSigNode* command_node_iterator = NULL;
	currentLine[0]='\0';

	env = request_memory_block();
	msg = get_buffer_start_(env);
	strcpy_(msg->mtext, "\n\r>> ");
	send_message(CRT_PROC_ID, env);
	env = NULL;
	msg = NULL;

	
	while(1){
		sent = 0;
		env = receive_message(&sender);
		msg = get_buffer_start_(env);
		if (msg->mtype == DEFAULT)
		{
			if (sender == 15)
			{
				letter = msg->mtext[0];
				if (letter == '\r' ||	letter == '\n')
				{
					if (current_char_index != 0) // Current input is not empty
					{
						command_node_iterator = commandListFront;
						found = 0;
						while (command_node_iterator != NULL)
						{
							found = 1;
							i = 0;
							while (1)
							{
								if (i < command_node_iterator->command_length)
								{
									if (command_node_iterator->mtext[i] != currentLine[i])
									{
										found = 0;
										break;
									}
								}
								else
								{
									if (currentLine[i] != '\0' && currentLine[i] != ' ')
									{
										found = 0;
									}
									break;
								}
								i++;
							}
							if (found)
							{
								break;
							}
							command_node_iterator = command_node_iterator->pNext;
							found = 0;
						}

						if (found)
						{
							// allocate new memory and send to registered process
							out_env = (int*)request_memory_block();
							out_msg = get_buffer_start_(out_env);
							strcpy_(out_msg->mtext, currentLine);
							send_message(command_node_iterator->sender, get_envelope_start(out_msg));

							strcpy_(msg->mtext, "\n\r>> ");
							send_message(CRT_PROC_ID, env);
							sent = 1;
						}
						else
						{
							strcpy_(msg->mtext, "\n\rCommand not found!\n\r>> ");
							send_message(CRT_PROC_ID, env);
							sent = 1;
						}
					}
					else // Current input is empty
					{
						strcpy_(msg->mtext, "\n\r>> ");
						send_message(CRT_PROC_ID, env);
						sent = 1;
					}
					currentLine[current_char_index = 0] = '\0';
				}
				else if (letter == 0x7F)
				{
					if (current_char_index > 0)
					{
						currentLine[--current_char_index] = '\0';
						send_message(CRT_PROC_ID, env);
						sent = 1;
					}
				}
				else if (current_char_index < MAX_INPUT_LENGTH)
				{
					currentLine[current_char_index++] = letter;
					currentLine[current_char_index] = '\0';
					send_message(CRT_PROC_ID, env);
					sent = 1;
				}
			}

			if (!sent)
			{
				release_memory_block(env);
			}
		}
		else if (msg->mtype == KCD_REG)
		{
			i = 0;
			while (msg->mtext[i] != '\0')
			{
				i++;
			}

			if (i < MAX_CMD_LENGTH)
			{
				if(commandListFront == NULL){
					commandListFront = (CommandSigNode*) msg;
					commandListBack = commandListFront;
					commandListFront->pNext = NULL;
					commandListFront->sender = sender;
					commandListFront->command_length = i;

				}else{
					commandListBack->pNext = (CommandSigNode*) msg;
					commandListBack = (CommandSigNode*) msg;
					commandListBack->pNext = NULL;
					commandListBack->sender = sender;
					commandListBack->command_length = i;
				}
			}
			else
			{
				release_memory_block(env);
			}
		}
		
		
		msg = NULL;
		env = NULL;
	}
}

void crtProc(void){
	int* env = NULL;
	msgbuf* msg = NULL;
	int sender = 0;
	LPC_UART_TypeDef *pUart = NULL;
	
	pUart = (LPC_UART_TypeDef *) LPC_UART0;
	
	while(1){
		env = (int*)receive_message(&sender);
		msg = get_buffer_start_(env);
		
		while(g_send_char){
			release_processor();
		}
		g_send_char = 1;
		strcpy_(gp_buffer,msg->mtext);
		
		pUart->IER = IER_THRE | IER_RLS | IER_RBR;
		release_memory_block(env);
		env = NULL;
		msg = NULL;
	}
}

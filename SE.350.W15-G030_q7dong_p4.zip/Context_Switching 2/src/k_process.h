/**
 * @file:   k_process.h
 * @brief:  process management hearder file
 * @author: Yiqing Huang
 * @author: Thomas Reidemeister
 * @date:   2014/01/17
 * NOTE: Assuming there are only two user processes in the system
 */

#ifndef K_PROCESS_H_
#define K_PROCESS_H_

#include "k_rtx.h"

/* ----- Definitions ----- */

#define INITIAL_xPSR 0x01000000        /* user process initial xPSR value */

// Special process ID's

#define SET_PRIORITY_PROC_ID		10
#define WALL_CLOCK_PROC_ID			11
#define KCD_PROC_ID							12
#define CRT_PROC_ID							13
#define I_PROCESS_TIMER_ID			14
#define I_PROCESS_UART_ID				15


/* ----- Structures ----- */
typedef struct queue 
{  
	U32 end;		/* last element's index in the queue */
	PCB *queueElements[NUM_TOTAL_PROCS];   /* state of the process */      
} Queue;



/* ----- Functions ----- */

int atomic(int status);																			/* adjust atomic level for current process */
void process_init(void);               											/* initialize all procs in the system */
PCB *scheduler(void);                										 		/* pick the pid of the next to run process */
int k_release_processor(void);       										    	/* kernel release_process function */
int k_set_process_priority(int process_id, int priority);		/* change the priority of a process*/	
int k_get_process_priority(int process_id);									/* get the priority of a process*/
int k_wait_for_memory(void);      									      	/* kernel block process (memory) function */
int k_memory_available(void);          											/* kernel unblock process (memory) function */
int k_send_message(int process_id, void* message_envelope);	/* kernel send message between processes */
int k_delayed_send(int process_id, void* message_envelope, int delay);
void* k_receive_message(int* sender_id);										/* kernel receive message */
void timer_i_process(void);							
void uart_i_process(void);	


extern U32 *alloc_stack(U32 size_b);   /* allocate stack for a process */
extern void __rte(void);               /* pop exception stack frame */
extern void set_test_procs(void);      /* test process initial set up */
extern void set_special_usr_procs(void);      /* test process initial set up */

#endif /* ! K_PROCESS_H_ */
